%% Frequency range
f = reshape(logspace(3,10,100000),[],1);
w = 2*pi*f;
%% PLL parameters
Kvco_rad = 200e6*(2*pi); % (rad/s)/V
Icp = 100e-6;        % A
Kpfdcp = Icp/(2*pi); % A/rad
N = 32;
PM = 60*(pi/180);   % rad, phase margin
Fc = 1e6;           % Hz, loop bandwidth, open-loop unit gain bandwidth
Wc = Fc*(2*pi);     % rad/s
%% Calculate LPF parameters
Tp = (sec(PM)-tan(PM))/Wc; % Time constant of pole;
Tz = 1/(Wc*Wc*Tp);
Ctotal = Kpfdcp*Kvco_rad/(N*Wc^2)*sqrt((1+(Wc*Tz)^2)/(1+(Wc*Tp)^2));
C1 = Ctotal*Tp/Tz;
C2 = Ctotal-C1;
R2 = Tz/C2;
% Display LPF parameters
fprintf('\nC2 = %.2f pF\n',C2*1e12);
% C2 = 120.65 pF
fprintf('\nC1 = %.2f pF\n',C1*1e12);
% C1 = 9.33 pF
fprintf('\nR2 = %.2f k%c\n',R2*1e-3,char(937));
% R2 = 4.92 kΩ
%%  Loop transfer function
num_LPF = 1/Ctotal*[Tz 1];        
den_LPF = [Tp 1 0]; 
LPF_tf = tf(num_LPF, den_LPF);

% num_LPF = [R2*C2/(C2+C1) 1/(C2+C1)];
% den_LPF = [R2*C2*C1/(C1+C2) 1 0]; 
% LPF_tf = tf(num_LPF, den_LPF);
% bode(LPF_tf)

num=Kvco_rad*Kpfdcp/N/Ctotal*[Tz 1];
den=[Tp 1 0 0];
Hopen_tf = tf(num,den) ;% open-loop transfer function
% 1Hopen_tf =
% 6.283e06 s + 1.058e13
% ---------------------
% 4.265e-08 s^3 + s^2
% Continuous-time transfer function.
Hff_tf = Hopen_tf*N; % feedforward gain
% Hff_tf =
% 2.011e08 s + 3.385e14
% ---------------------
% 4.265e-08 s^3 + s^2
% Continuous-time transfer function.
Hclose_tf = Hff_tf/(1+Hopen_tf); % close loop gain
% Hclose_tf =
% 8.574 s^4 + 2.155e08 s^3 + 3.385e14 s^2
% -----------------------------------------------------------------------
% 1.819e-15 s^6 + 8.529e-08 s^5 + 1.268 s^4 + 6.734e06 s^3 + 1.058e13 s^2
% Continuous-time transfer function.
Hopen = reshape(freqresp(Hff_tf,w),[],1);
Hclose = reshape(freqresp(Hclose_tf,w),[],1);
%%  Calculate phase margin and unit-gain bandwidth
[~,PhaseMargin,~,UGW]=margin(Hopen_tf);
% PhaseMargin = 60.0000
% UGW = 6.2832e+06
UnitGainFrequency = UGW/2/pi;
% UnitGainFrequency = 1.0000e+06
BW_open = UnitGainFrequency;
% BW_open = 1.0000e+06
fprintf('\nOpen-loop Unit-Gain Frequency = %.2f MHz\n', BW_open*1e-6);
% Open-loop Unit-Gain Frequency = 1.00 MHz
%% Calculate closed-loop -3dB bandwidth
BW_close = bandwidth(Hclose_tf)/(2*pi);
% BW_close = 1.5623e+06
fprintf('Closed-loop -3dB Bandwidth = %.2f MHz\n\n', BW_close*1e-6);
% 2Closed-loop -3dB Bandwidth = 1.56 MHz

%%  Plot open loop frequency response
h = figure('Name','Open-Loop Transfer Function','NumberTitle','off');
bodePrefs = bodeoptions;
bodePrefs.FreqUnits = 'Hz';
bodePrefs.Grid = 'on';
bodePrefs.Title.String=sprintf...
('Bode-Plot (Phase Margin: %.2f%c, Loop BW: %.2f MHz)',...
PhaseMargin,char(176),UnitGainFrequency*1e-6);
bodePrefs.Title.FontSize=12;
bodePrefs.Title.FontWeight='bold';
bodePrefs.XLabel.FontSize=12;
bodePrefs.YLabel.FontSize=12;
bodePrefs.TickLabel.FontSize=12;
bodeplot(Hopen_tf,bodePrefs,'r');hold on;
set(gca, 'XLim', [1e3 1e8]);
% set(gca, 'YLim', [-180,-20]);
xticks([1e3 1e4 1e5 1e6 10e6 100e6]);
xticklabels({'1k','10k','100k','1M','10M','100M'});
%% Plot a vertical line to indicate the unit gain frequency (UGF)
children = get(h,'Children');% obtain list of figure's children
% We see that children has 3 objects:
% 1) Context Menu
% 2) Axis object to Phase Plot
% 3) Axis object to Magnitude Plot
% Plot line in Magnitude Plot
magChild = children(3); % Pick a handle to axes of magnitude in bode diagram
axes(magChild) % Make those axes current
semilogx([UGW UGW]/2/pi,[-360 0],'linestyle','--');
% Plot line in Phase Plot
magChild = children(2); % Pick a handle to axes of magnitude in bode diagram
axes(magChild) % Make those axes current
semilogx([UGW UGW]/2/pi,[-360 0],'linestyle','--');
%% Plot close loop frequency response
figure('Name','Closed-Loop Transfer Function','NumberTitle','off');
bodePrefs = bodeoptions;
bodePrefs.FreqUnits = 'Hz';
bodePrefs.Grid = 'on';
bodePrefs.PhaseVisible = 'off';
[bandw,~,bandw_u]=engunits(bandwidth(Hclose_tf)/(2*pi));
bodePrefs.Title.String=sprintf('Magnitude Response (Closed-Loop BW: %.2f %sHz)'...
,bandw,bandw_u);
bodePrefs.Title.FontSize=12;
bodePrefs.Title.FontWeight='bold';
bodePrefs.XLabel.FontSize=12;
bodePrefs.YLabel.FontSize=12;
bodePrefs.TickLabel.FontSize=12;
bodeplot(Hclose_tf,bodePrefs,'r');
set(gca, 'XLim', [1e3 1e8]);
%% Step Response
figure('Name','Step Response','NumberTitle','off');
[step_y,step_t]=step(Hclose_tf); % step-response normalized to a unity gain
[stepT,~,stepT_u]=engunits(step_t);
plot(stepT,step_y ,'r');
% step(Hclose_tf);
grid on;
set(gca,'FontSize',12');% axis
xlabel(['Time (in ',stepT_u,'s)'],'FontSize',12);
ylabel('Amplitude','FontSize',12);
title('Step Response','FontSize',12);
stepInfo=stepinfo(Hclose_tf);
[rise,~,rise_u]=engunits(stepInfo.RiseTime);
[set,~,set_u]=engunits(stepInfo.SettlingTime);
string=sprintf...
(['Rise Time: %.2f %ss\nSettling Time: %.2f %ss\nPercentage' ...
'Overshoot: %.2f\nPeak value: %.2f']...
,rise,rise_u,set,set_u,stepInfo.Overshoot,stepInfo.Peak);
text(stepT(floor(length(stepT)/4)),(max(step_y)-min(step_y))/2,...
string,'FontSize',12);




