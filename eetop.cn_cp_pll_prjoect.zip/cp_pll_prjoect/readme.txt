本项目主要展示如何利用maltab和simulink搭建cp pll模型，仅作为记录和分享使用，欢迎批评指正。

使用方法如下，直接运行transfunc_noise.m 即可

涉及主要的文件为:
（1）transfunc_noise.m (这里面已经包含了para_calculation 和Simulink_para_define)
（2）CP_PLL.slx是利用Mixed-Signal Blockset/PLL/Building Blocks里模型搭建，第一个行为级建模（运行后可以通过数据检查器查看波形），第二个是信号流图传输函数建模（通过模型线性化器可以导出传递函数，linsys1_model.mat即是通过此种方法导出）。


模块说明：
para_calculation.m 是完全根据杨老师开源的代码copy过来的，可以对照杨老师的设计文档查看。是在给定Icp Kvco N PM wc的条件下根据最大相位裕度法求出 LPF的参数，并绘制开环&闭环传递函数，阶跃响应（这里感觉Hopen_tf应该表征的是闭环传递函数不知道理解的对不对但不影响使用）

Simulink_para_define.m 是给CP_PLL.slx行为级模型定义设计参数的

transfunc_noise.m是对传输函数进行建模（通过matalb建模以及simulink建模两种方式交叉验证正确性），同时对噪声进行模拟（略微粗糙，只是为了模拟其行为，后续可以从实际电路导出噪声进行分析），并计算出其等效到输出端的噪声。



小弟也是初学者，请大家多多交流指教1569411179@qq.com          ---by LWang
