%{
NBuffer = 1e5;
DeadbandCompensation = 1e-10;
OutputCurrent = 6e-4;      % A
C1 = 7.8e-10;              % F
C2 = 1.16e-8;              % F
R2 = 467;                  % Ohm
N = 1;
NBufferFilter = 1e5;
InputThreshold = 0.1;
Kvco = 2000000;            % Hz/V
Amplitude = 1;
Fo = 12000000;             % Hz
Tin = 1/Fo;                % s

% 转换单位
fref_MHz = Fo/1e6;
Icp_mA   = OutputCurrent*1e3;
Kvco_MHz_V = Kvco/1e6;

% 打印结果
fprintf('fref = %.3f MHz\n', fref_MHz);
fprintf('N    = %d\n', N);
fprintf('Icp  = %.3f mA\n', Icp_mA);
fprintf('Kvco = %.3f MHz/V\n', Kvco_MHz_V);
fprintf('C1   = %.3e F\n', C1);
fprintf('C2   = %.3e F\n', C2);
fprintf('R2   = %.3f Ohm\n', R2);

%}

NBuffer = 1e5;
DeadbandCompensation = 1e-11;
OutputCurrent = Icp;      % A
C1 = C1;              % F
C2 = C2;              % F
R2 = R2;                  % Ohm
N = N;
NBufferFilter = 1e5;
InputThreshold = 0.1;
Kvco = Kvco_rad/2/pi;            % Hz/V
Amplitude = 1;
Fo = 350e6;
Fin = 16e6;             % Hz
Tin = 1/Fin;                % s

Fout_ideal = Fin * N;
Fout_1V = Fo + Kvco*1;
fprintf('Fout_ideal   = %.3f MHz\n', Fout_ideal/1e6);
fprintf('Fout_1V      = %.3f MHz\n', Fout_1V/1e6);


% 转换单位
fref_MHz = Fin/1e6;
Icp_mA   = OutputCurrent*1e3;
Kvco_MHz_V = Kvco/1e6;

% 打印结果
fprintf('fref = %.3f MHz\n', fref_MHz);
fprintf('N    = %d\n', N);
fprintf('Icp  = %.3f mA\n', Icp_mA);
fprintf('Kvco = %.3f MHz/V\n', Kvco_MHz_V);
fprintf('C1   = %.3e F\n', C1);
fprintf('C2   = %.3e F\n', C2);
fprintf('R2   = %.3f Ohm\n', R2);






%% 其他参数Simulation

%PFD

MaxFreqInterest = 10e9;
RiseFallTime = 30e-12;
PropDelay = 50e-12;


%CP
CurrentImbalance = 1e-7;
LeakageCurrent = 1e-8; 

RiseFallUp = 5e-9;
PropDelayUp = 6e-9;

RiseFallDown = 2e-9;
PropDelayDown = 4e-9;

MaxFreqInterestCp = 10e9;

%LPF
Temperature = 27; 

%VCO
Foffset =  [30e3 100e3 1e6 3e6 10e6];
PhaseNoise = [-56 -106 -132 -143 -152];






%% measurement
FreqErrorTol = 1e5;
ResBandwidth = 25000;

TargetLockTime = 1e-3;
TargetPhaseNoiseVector = [-85,-125,-150,-180];
HoldOffTime = 2e-5;
PhaseNoiseFreqOffset = [300e3 1e6 3e6 10e6];