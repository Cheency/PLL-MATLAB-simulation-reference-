clc;
clear;
para_calculation;
Simulink_para_define;
%% 传递函数建模------手动计算
  
    s = tf('s');
     % Forward gain definitions
    matlab_Gref_forward   = Kpfdcp * LPF_tf * (Kvco_rad / s);
    matlab_Gpfdcp_forward = LPF_tf * (Kvco_rad / s);
    matlab_Glpf_forward   = Kvco_rad / s;
    matlab_Gdiv_forward   = - Kpfdcp * LPF_tf * (Kvco_rad / s);
    matlab_Gvco_forward   = 1;
    
    % Closed-loop transfer functions (直接化简)
    matlab_tf_vref  = minreal(matlab_Gref_forward   / (1 + Hopen_tf));
    matlab_tf_pfdcp = minreal(matlab_Gpfdcp_forward / (1 + Hopen_tf));
    matlab_tf_lpf   = minreal(matlab_Glpf_forward   / (1 + Hopen_tf));
    matlab_tf_div   = minreal(matlab_Gdiv_forward   / (1 + Hopen_tf));
    matlab_tf_vco   = minreal(matlab_Gvco_forward   / (1 + Hopen_tf));
    
    
   % 频率响应
    H_vref_freq  = reshape(freqresp(matlab_tf_vref,  w), [], 1);
    H_pfdcp_freq = reshape(freqresp(matlab_tf_pfdcp, w), [], 1);
    H_lpf_freq   = reshape(freqresp(matlab_tf_lpf,   w), [], 1);
    H_div_freq   = reshape(freqresp(matlab_tf_div,   w), [], 1);
    H_vco_freq   = reshape(freqresp(matlab_tf_vco,   w), [], 1);
    
    % Bode 图（单独）
    figure; bode(matlab_tf_vref);  grid on; title('matlab\_Vref\_noise → VCO\_out');
    figure; bode(matlab_tf_pfdcp); grid on; title('matlab\_PFDCP\_noise → VCO\_out');
    figure; bode(matlab_tf_lpf);   grid on; title('matlab\_LPF\_noise → VCO\_out');
    figure; bode(matlab_tf_div);   grid on; title('matlab\_Divider\_noise → VCO\_out');
    figure; bode(matlab_tf_vco);   grid on; title('matlab\_VCO\_noise → VCO\_out');
    
    % 合并图
    figure;
    bode(matlab_tf_vref,'r', matlab_tf_pfdcp,'g', matlab_tf_lpf,'b', matlab_tf_div,'m', matlab_tf_vco,'k');
    grid on;
    legend('Vref','PFDCP','LPF','Divider','VCO');
    title('Manual (matlab\_) Transfer Functions to VCO\_out (minreal)');
    
    % 五个Bode图放在同一个大图中
    figure('Name','Noise Source Transfer Functions','NumberTitle','off');
    
    tfs  = {matlab_tf_vref, matlab_tf_pfdcp, matlab_tf_lpf, matlab_tf_div, matlab_tf_vco};
    names = {'Vref noise → VCO_{out}', 'PFDCP noise → VCO_{out}', ...
             'LPF noise → VCO_{out}', 'Divider noise → VCO_{out}', ...
             'VCO noise → VCO_{out}'};
    colors = {'r','g','b','m','k'};
    for i = 1:5
        subplot(2,3,i); % 2行3列布局，中间会留一个空格
        bode(tfs{i}, colors{i});
        grid on;
        title(names{i}, 'Interpreter', 'none');
    end
    sgtitle('Bode Plots of Different Noise Sources (MATLAB Model)');



%% 传递函数建模------Simulink 导出
    load('linsys1_model.mat','linsys1');
    % 提取每一个输入到输出的传递函数
    Simulink_G_vref     = linsys1('VCO_out','Vref_noise');
    Simulink_G_pfdcp    = linsys1('VCO_out','PFDCP_noise');
    Simulink_G_lpf      = linsys1('VCO_out','LPF_noise');
    Simulink_G_divider  = linsys1('VCO_out','Divider_nois');
    Simulink_G_vco      = linsys1('VCO_out','VCO_noise');
    
    % 转换成传递函数形式
    Simulink_tf_vref    = tf(Simulink_G_vref);
    Simulink_tf_pfdcp   = tf(Simulink_G_pfdcp);
    Simulink_tf_lpf     = tf(Simulink_G_lpf);
    Simulink_tf_divider = tf(Simulink_G_divider);
    Simulink_tf_vco     = tf(Simulink_G_vco);
    
    %{
    % 画 bode 图（每个单独一张图）
    figure; bode(Simulink_tf_vref);    grid on; title('Transfer Function: Vref\_noise → VCO\_out');
    figure; bode(Simulink_tf_pfdcp);   grid on; title('Transfer Function: PFDCP\_noise → VCO\_out');
    figure; bode(Simulink_tf_lpf);     grid on; title('Transfer Function: LPF\_noise → VCO\_out');
    figure; bode(Simulink_tf_divider); grid on; title('Transfer Function: Divider\_noise → VCO\_out');
    figure; bode(Simulink_tf_vco);     grid on; title('Transfer Function: VCO\_noise → VCO\_out');
    %}
    

        % 绘制子图（第一行3个，第二行2个）
    figure('Name','Simulink Transfer Functions','NumberTitle','off');
    tfs = {Simulink_tf_vref, Simulink_tf_pfdcp, Simulink_tf_lpf, Simulink_tf_divider, Simulink_tf_vco};
    names = {'Vref noise → VCO_{out}', 'PFDCP noise → VCO_{out}', ...
             'LPF noise → VCO_{out}', 'Divider noise → VCO_{out}', ...
             'VCO noise → VCO_{out}'};
    colors = {'r','g','b','m','k'};
    
    for i = 1:5
        subplot(2,3,i);               % 第一行3个，第二行2个
        bode(tfs{i}, colors{i});
        grid on;
        title(names{i}, 'Interpreter', 'none', 'FontSize', 9);
    end
    
    sgtitle('Bode Plots of Different Noise Sources (Simulink Model)');
    %set(gcf, 'Position', [100, 100, 1600, 800]);  % 调整窗口大小
    
        % 所有传递函数画在同一个图里
        figure;
        bode(Simulink_tf_vref,'r', Simulink_tf_pfdcp,'g', Simulink_tf_lpf,'b', Simulink_tf_divider,'m', Simulink_tf_vco,'k');
        grid on;
        legend('Vref\_noise','PFDCP\_noise','LPF\_noise','Divider\_noise','VCO\_noise');
        title('All Transfer Functions to VCO\_out');





 %% 噪声建模

w = 2*pi*f;        % 角频率
s = 1j*w;          % 复频域变量

% --- VCO 相位噪声 ---
pn   = -109;       % VCO phase noise @100 kHz offset
f0   = 1e5;        % 归一化参考频点

% 根据频率区间使用不同指数
Vnvco = zeros(size(f));
idx1 = f <= f0;    % 前半段：1 kHz - 100 kHz，30 dB/dec -> exponent 1.5
Vnvco(idx1) = 10^(pn/20) ./ ( (f(idx1)/f0).^1.5 );
idx2 = f > f0;     % 后半段：100 kHz - 10 GHz，20 dB/dec -> exponent 1
Vnvco(idx2) = 10^(pn/20) ./ ( (f(idx2)/f0) );

pn_vco_dBc = 20*log10(Vnvco);

% % 绘图
figure;
semilogx(f, pn_vco_dBc, 'LineWidth', 1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Phase Noise (dBc/Hz)');
title('VCO Phase Noise vs Offset Frequency');


% --- Crystal 相位噪声 ---
pnx  = -115;             % crystal phase noise @1kHz offset
f1   = 1e3;              % 归一化参考频点
Vncrs = 10^(pnx/20) ./ ( (f./f1) .^ 1 );
pn_crystal_dBc = 20*log10(Vncrs);

% 绘图
figure;
semilogx(f, pn_crystal_dBc, 'LineWidth', 1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Phase Noise (dBc/Hz)');
title('Crystal Oscillator Phase Noise vs Offset Frequency');

% --- LPF 热噪声 (R2) ---
% 电路示意：
% ------+---------
%     |         |           
%    C1        C2
%     |         | ------  
%     |         |      |
%     |        R2     InR2
%     |         | -----|  
%              GND
k = 1.38e-23; 
T = 300;
VnR2 = sqrt(4*k*T*R2);   % R2 电压噪声
InR2 = sqrt(4*k*T/R2);   % 电流噪声
Ceq  = C1*C2/(C1+C2);    % 等效电容
Ztot = R2 ./ (1 + s*R2*Ceq);
VnLPF = InR2 .* Ztot .* (C2/(C1+C2));

%绘图
figure;
semilogx(f, 20*log10(abs(VnLPF)));
grid on;
xlabel('Frequency (Hz)');
ylabel('Noise Gain (dB)');
title('R2 Thermal Noise to Output (Bode Plot)');

% --- Charge Pump (CP) 噪声 ---
Ton   = 1e-9;            % PFD 背隙时间
fcor  = 1e5;             % 参考频率
Incur = 4e-12*sqrt(Icp/0.5e-3) + 6e-12; % 包含 OPAMP 主动滤波噪声
lncp  = sqrt(Incur^2./(f/fcor)) + Incur;
lncp_dB = 20*log10(lncp);

%绘图
figure;
semilogx(f, lncp_dB, 'LineWidth', 1.5);
grid on;
xlabel('Frequency (Hz)');
ylabel('Noise Density (dBc/Hz)');
title('Charge Pump Noise Spectrum in dBc/Hz');

% --- Divider噪声建模 ---

Vndiv_amp = 1e-12;                 % Divider 白噪声幅值 (V/√Hz)，很小
Vndiv = Vndiv_amp * ones(size(f)); % 频率上恒定 -> 白噪声

% 转换为 dBc/Hz 可选
Vndiv_dBc = 20*log10(Vndiv);

%% 计算各个噪声源经过系统传递函数后的输出噪声谱
H_vref  = squeeze(freqresp(matlab_tf_vref,  w));
H_pfdcp = squeeze(freqresp(matlab_tf_pfdcp, w));
H_lpf   = squeeze(freqresp(matlab_tf_lpf,   w));
H_div   = squeeze(freqresp(matlab_tf_div,   w));
H_vco   = squeeze(freqresp(matlab_tf_vco,   w));

Svco     = abs(Vnvco).^2;       % VCO 相位噪声功率谱
Scrystal = abs(Vncrs).^2;       % 晶体振荡器噪声功率谱
Slpf     = abs(VnLPF).^2;       % LPF 热噪声功率谱
Scp      = abs(lncp).^2;        % Charge Pump 噪声功率谱
Sdiv     = abs(Vndiv).^2;             % Divider 功率谱           % 设定常数白噪声 PSD

Sout_vref  = abs(H_vref ).^2 .* Scrystal;  % Ref 噪声经过 VCO 输出传递
Sout_pfdcp = abs(H_pfdcp).^2 .* Scp;      % CP 噪声经过传递
Sout_lpf   = abs(H_lpf  ).^2 .* Slpf;     % LPF 噪声经过传递
Sout_div   = abs(H_div  ).^2 .* Sdiv;  % Divider 引入的 Ref 噪声
Sout_vco   = abs(H_vco  ).^2 .* Svco;     % VCO 自身噪声

Sout_total = Sout_vref + Sout_pfdcp + Sout_lpf + Sout_div + Sout_vco;

%% 总噪声曲线
figure;
loglog(f, sqrt(Sout_total), 'c', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Output Noise Spectral Density (V/√Hz)');
title('Total Noise at VCO Output');
legend('Total');
text(1e4, max(sqrt(Sout_total))*0.8, 'Total output noise', 'Color','c');

% 单独绘制每个噪声源
figure;
loglog(f, sqrt(Sout_vref), 'r', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (V/√Hz)');
title('VCO Output Noise Contribution: Reference Oscillator');
text(1e4, max(sqrt(Sout_vref))*0.8, 'Ref Noise', 'Color','r');

figure;
loglog(f, sqrt(Sout_pfdcp), 'g', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (V/√Hz)');
title('VCO Output Noise Contribution: Charge Pump');
text(1e4, max(sqrt(Sout_pfdcp))*0.8, 'CP Noise', 'Color','g');

figure;
loglog(f, sqrt(Sout_lpf), 'b', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (V/√Hz)');
title('VCO Output Noise Contribution: LPF');
text(1e4, max(sqrt(Sout_lpf))*0.8, 'LPF Noise', 'Color','b');

figure;
loglog(f, sqrt(Sout_div), 'm', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (V/√Hz)');
title('VCO Output Noise Contribution: Divider');
text(1e4, max(sqrt(Sout_div))*0.8, 'Divider Noise', 'Color','m');

figure;
loglog(f, sqrt(Sout_vco), 'k', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (V/√Hz)');
title('VCO Output Noise Contribution: VCO Itself');
text(1e4, max(sqrt(Sout_vco))*0.8, 'VCO Noise', 'Color','k');


% 所有噪声源及总噪声绘制在一张图
figure;
loglog(f, sqrt(Sout_vref),  'r', 'LineWidth',1.5); hold on;
loglog(f, sqrt(Sout_pfdcp),'g', 'LineWidth',1.5);
loglog(f, sqrt(Sout_lpf),  'b', 'LineWidth',1.5);
loglog(f, sqrt(Sout_div),  'm', 'LineWidth',1.5);
loglog(f, sqrt(Sout_vco),  'k', 'LineWidth',1.5);
loglog(f, sqrt(Sout_total), 'x', 'LineWidth', 2);  % 总噪声，用叉号标记，默认颜色


hold off;

grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (V/√Hz)');
title('Noise Contributions at VCO Output');
legend('Ref','CP','LPF','Divider','VCO','Total','Location','best');



%% 单独绘制每个噪声源 (dB 单位)
figure;
semilogx(f, 20*log10(sqrt(Sout_vref)), 'r', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (dBV/√Hz)');
title('VCO Output Noise Contribution: Reference Oscillator');
text(1e4, max(20*log10(sqrt(Sout_vref)))*0.95, 'Ref Noise', 'Color','r');

figure;
semilogx(f, 20*log10(sqrt(Sout_pfdcp)), 'g', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (dBV/√Hz)');
title('VCO Output Noise Contribution: Charge Pump');
text(1e4, max(20*log10(sqrt(Sout_pfdcp)))*0.95, 'CP Noise', 'Color','g');

figure;
semilogx(f, 20*log10(sqrt(Sout_lpf)), 'b', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (dBV/√Hz)');
title('VCO Output Noise Contribution: LPF');
text(1e4, max(20*log10(sqrt(Sout_lpf)))*0.95, 'LPF Noise', 'Color','b');

figure;
semilogx(f, 20*log10(sqrt(Sout_div)), 'm', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (dBV/√Hz)');
title('VCO Output Noise Contribution: Divider');
text(1e4, max(20*log10(sqrt(Sout_div)))*0.95, 'Divider Noise', 'Color','m');

figure;
semilogx(f, 20*log10(sqrt(Sout_vco)), 'k', 'LineWidth',1.5);
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (dBV/√Hz)');
title('VCO Output Noise Contribution: VCO Itself');
text(1e4, max(20*log10(sqrt(Sout_vco)))*0.95, 'VCO Noise', 'Color','k');

% 所有噪声源及总噪声绘制在一张图 (dB 单位)
figure;
semilogx(f, 20*log10(sqrt(Sout_vref)),  'r', 'LineWidth',1.5); hold on;
semilogx(f, 20*log10(sqrt(Sout_pfdcp)),'g', 'LineWidth',1.5);
semilogx(f, 20*log10(sqrt(Sout_lpf)),  'b', 'LineWidth',1.5);
semilogx(f, 20*log10(sqrt(Sout_div)),  'm', 'LineWidth',1.5);
semilogx(f, 20*log10(sqrt(Sout_vco)),  'k', 'LineWidth',1.5);
semilogx(f, 20*log10(sqrt(Sout_total)), 'x', 'LineWidth', 2);  % 总噪声叉号标记

hold off;
grid on;
xlabel('Offset Frequency (Hz)');
ylabel('Noise Spectral Density (dBV/√Hz)');
title('Noise Contributions at VCO Output (in dB)');
legend('Ref','CP','LPF','Divider','VCO','Total','Location','best');
